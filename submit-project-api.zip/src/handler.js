const { nanoid } = require('nanoid')
const books = require('./books')

// Menambahkan data buku
const addBook = (request, h) => {
  const {
    name,
    year,
    author,
    summary,
    publisher,
    pageCount,
    readPage,
    reading,
  } = request.payload

  const id = nanoid(16)
  const finished = pageCount === readPage ? true : false
  const insertedAt = new Date().toISOString()
  const updatedAt = insertedAt
  const newBook = {
    id,
    name,
    year,
    author,
    summary,
    publisher,
    pageCount,
    readPage,
    finished,
    reading,
    insertedAt,
    updatedAt,
  }

  if (name === undefined)  {
    const response = h.response({
      status: 'fail',
      message: 'Gagal menambahkan buku. Mohon isi nama buku',
    })
    response.code(400)

    return response
  }

  if (readPage > pageCount) {
    const response = h.response({
      status: 'fail',
      message: 'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount',
    })
    response.code(400)

    return response
  }

  books.push(newBook)

  const isSuccess = books.filter((value) => value.id === id).length > 0

  if (isSuccess) {
    const response = h.response({
      status: 'success',
      message: 'Buku berhasil ditambahkan',
      data: {
        bookId: id,
      },
    })
    response.code(201)
    return response
  }

  const response = h.response({
    status: 'fail',
    message: 'Buku gagal ditambahkan',
  })
  response.code(500)
  return response
}

// Mendapatkan semua data buku
const getAllBooks = (request, h) => {
  const { name, reading, finished } = request.query

  if (books.length === 0) {
    const response = h.response({
      status: 'success',
      data: {
        books: [],
      },
    });

    response.code(200);
    return response;
  }

  let filteredBooks = books

  if (name !== undefined) {
    filteredBooks = filteredBooks.filter((value) => value
      .name.toLowerCase().includes(name.toLowerCase()))
  }

  if (reading !== undefined) {
    filteredBooks = filteredBooks.filter((value) => value.reading === !!Number(reading))
  }

  if (finished !== undefined) {
    filteredBooks = filteredBooks.filter((value) => value.finished === !!Number(finished))
  }

  // manangkap data buku
  const catchBook = filteredBooks.map((value) => ({
    id: value.id,
    name: value.name,
    publisher: value.publisher,
  }));

  const response = h.response({
    status: 'success',
    data: {
      books: catchBook,
    },
  });

  response.code(200);
  return response;

  // const response = h.response({
  //   status: 'success',
  //   data: {
  //     books: filteredBooks.map((value) => ({
  //       id: value.id,
  //       name: value.name,
  //       publisher: value.publisher,
  //     })),
  //   },
  // })
  // response.code(200)
  // return response
}

// Mendapatkan data buku dari Id
const getBookById = (request, h) => {
  
  const { id } = request.params
  
  const book = books.filter((value) => value.id === id)[0]

  if (book !== undefined) {
    return {
      status: 'success',
      data: {
        book
      }
    }
  }

  const response = h.response({
    status: 'fail',
    message: 'Buku tidak ditemukan',
  })
  response.code(404)
  return response
}

// Mengubah buku
const editBookById = (request, h) => {

  const { id } = request.params;

  const {
    name,
    year,
    author,
    summary,
    publisher,
    pageCount,
    readPage,
    reading,
  } = request.payload
  
  const updatedAt = new Date().toISOString()
  const indexFromId = books.findIndex((value) => value.id === id)

  if (name === undefined) {
    const response = h.response({
      status: 'fail',
      message: 'Gagal memperbarui buku. Mohon isi nama buku',
    })
    response.code(400)
    return response
  } 
  
  if (readPage > pageCount) {
    const response = h.response({
      status: 'fail',
      message:
        'Gagal memperbarui buku. readPage tidak boleh lebih besar dari pageCount',
    })
    response.code(400)
    return response;
  } 
  
  if (indexFromId !== -1) {
    books[indexFromId] = {
      ...books[indexFromId],
      name,
      year,
      author,
      summary,
      publisher,
      pageCount,
      readPage,
      reading,
      updatedAt,
    }
    const response = h.response({
      status: 'success',
      message: 'Buku berhasil diperbarui',
    })
    response.code(200);
    return response;
  } 

    const response = h.response({
      status: 'fail',
      message: 'Gagal memperbarui buku. Id tidak ditemukan',
    })
    response.code(404);
    return response
}


// Menghapus Buku
const deleteBookById = (request, h) => {
  
  const { id } = request.params
  
  const indexFromId = books.findIndex((value) => value.id === id)

  if (indexFromId !== -1) {
    books.splice(indexFromId, 1)
    const response = h.response({
      status: 'success',
      message: 'Buku berhasil dihapus',
    })
    response.code(200)

    return response
  }

  const response = h.response({
    status: 'fail',
    message: 'Buku gagal dihapus. Id tidak ditemukan',
  })
  response.code(404)
  return response
}


// ekspor module
module.exports = {
  addBook,
  getAllBooks,
  getBookById,
  editBookById,
  deleteBookById,
}